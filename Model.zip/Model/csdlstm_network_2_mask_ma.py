
import torch
import torch.nn as nn
import evaluation
from tqdm import tqdm
import torch.nn.functional as F
import numpy as np
from torch.optim.lr_scheduler import CosineAnnealingWarmRestarts

class smile_lc(nn.Module):
    def __init__(self,hidden_size,output_size, n_layers,n_heads):
        super(smile_lc,self).__init__()
        self.mask = nn.Parameter(torch.ones(10, 55))
        # LSTM层
        self.lstml = nn.LSTM(25, hidden_size, n_layers, batch_first=True)
        self.lstmo = nn.LSTM(19, hidden_size, n_layers, batch_first=True)
        self.lstmr = nn.LSTM(25, hidden_size, n_layers, batch_first=True)
        self.lstme = nn.LSTM(7, hidden_size, n_layers, batch_first=True)
        self.conv_1 = nn.Conv2d(in_channels=1, out_channels=16, kernel_size=(3, 3), stride=1, padding=(1, 1))
        self.conv_2 = nn.Conv2d(in_channels=16, out_channels=32, kernel_size=(3, 3), stride=1, padding=(1, 1))
        self.bn1=nn.BatchNorm2d(16)
        self.bn2=nn.BatchNorm2d(32)
        self.pool1=nn.MaxPool2d(kernel_size=(2,2),stride=(2,2))
        self.pool2 = nn.MaxPool2d(kernel_size=(2, 2), stride=(2, 2))
        # 第一个全连接层
        self.fc1 = nn.Linear(32*int(hidden_size/4), 64)
        self.fc2 = nn.Linear(64, output_size)
        self.multihead=nn.MultiheadAttention(hidden_size,n_heads,batch_first=True)

    def forward(self, x):
        x = x * torch.sigmoid(self.mask.unsqueeze(0))
        pre=x[:,:,0:6];fol=x[:,:,6:12];leftp=x[:,:,12:18];
        lefta=x[:,:,18:24];leftf=x[:,:,24:30];rightp=x[:,:,30:36]
        righta=x[:,:,36:42];rightf=x[:,:,42:48];ego=x[:,:,48:55]
        i_ego=torch.cat((pre,fol,ego),dim=2)
        i_right=torch.cat((rightp,righta,rightf,ego),dim=2)
        i_left=torch.cat((leftp,lefta,leftf,ego),dim=2)
        x1,_=self.lstmo(i_ego);x1=x1[:,-1,:]
        x2,_=self.lstml(i_left);x2=x2[:,-1,:]
        x3,_=self.lstmr(i_right);x3=x3[:,-1,:]
        x4,_=self.lstme(ego);x4=x4[:,-1,:]
        x1=x1.unsqueeze(1);x2=x2.unsqueeze(1);x3=x3.unsqueeze(1);x4=x4.unsqueeze(1)
        i_other = torch.cat((x1, x2, x3,x4), dim=1)#[B,4,H]
        i_other,_=self.multihead(i_other,i_other,i_other)
        i_other=i_other.unsqueeze(1)#[B,1,4,H]
        i_other= self.pool1(F.relu(self.bn1(self.conv_1(i_other))))#B,16,2,H/2
        i_other=self.pool2(F.relu(self.bn2(self.conv_2(i_other))))#B,32,1,H/4
        i_other=i_other.view(i_other.shape[0], -1)
        final_out=F.relu(self.fc1(i_other))
        final_out=self.fc2(final_out)
        return final_out

    def training_lstm(self, train_loader, test_loader, t_lr, s_path, percep,device):  #
        model_path = 'D:\Project\Intenrion_feature_map\Dataset\Data_417\Models\Train_model\hyper_opt\smile_lc/P_' + str(percep) + '/' + s_path
        val_loss = 100
        train_loss_all = [];
        val_loss_all = []
        criterion = nn.CrossEntropyLoss()
        optimizer = torch.optim.Adam(self.parameters(), lr=t_lr, weight_decay=3e-4)
        scheduler = CosineAnnealingWarmRestarts(optimizer, 100, T_mult=1, eta_min=1e-5,
                                                last_epoch=-1)  # , verbose=False
        for e in tqdm(range(100)):  # 现实训练模型的进度条
            self.train()
            Loss = []
            for images, labels in train_loader:
                images = images.to(device)
                labels = labels.to(device)
                outputs = self(images)
                loss = criterion(outputs, labels)  # calculate the loss
                # Backward and optimize
                loss.backward()  # update gradient
                # torch.nn.utils.clip_grad_norm_(self.parameters(), max_norm=1.0)  # 梯度剪裁
                optimizer.step()  # update parameters
                optimizer.zero_grad()  # clear the gradient
                Loss.append(loss.item())
            scheduler.step()
            train_loss_all.append(np.mean(Loss))

            self.eval()
            Loss = []
            with torch.no_grad():
                for images, labels in test_loader:
                    images = images.to(device)
                    labels = labels.to(device)
                    outputs = self(images)
                    loss2 = criterion(outputs, labels)  # calculate the loss
                    Loss.append(loss2.item())
                val_loss_all.append(np.mean(Loss))
            if np.mean(Loss) < val_loss:
                evaluation.save_model(self, save_path=model_path)
                val_loss = np.mean(Loss)
        return val_loss

    def predict(self,test_x):
        self.eval()
        with torch.no_grad():
            out = self(test_x)
        return out