import pandas as pd
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.font_manager as fm
import numpy as np
import os
import xlwt
import math
import random
import pickle
import torch
import evaluation

from sklearn.metrics import accuracy_score,mean_squared_error,r2_score
import time
import shutil
import torch
from torch.utils.data import DataLoader, TensorDataset,Dataset

import time
# import bi_lstm_ma
# import cslstm_a
# import cslstm_b
# import lstm_cnn
#
# import mask_Transformer
# import mask_lstm_cnn
# import mask_cnn_lstm_ma
# import mask_bi_lstm_ma
#import cnn_lstm_ma
import csdlstm_network_2_mask_ma
def max_index(data):
    max_id=0;max_v=0
    for i in range(len(data)):
        if data[i]>=max_v:
            max_id=i;
            max_v=data[i]
    return max_id

random.seed(3407)
# 固定NumPy的随机种子
np.random.seed(3407)
# 固定PyTorch的随机种子
torch.manual_seed(3407)
# 如果你的代码使用了CUDA
if torch.cuda.is_available():
    torch.cuda.manual_seed(3407)
    torch.cuda.manual_seed_all(3407)  # 如果使用多个CUDA设备
    # 以下两行为确保CUDA的行为是确定性的，但可能会影响性能
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
# 设置环境变量以进一步确保可重复性
os.environ['PYTHONHASHSEED'] = str(3407)


T=[4]#,,，2,3344
P=[50,100,150]#,,50,10050,100,50,100,
mode='test'
#model structure
#P_50 lr: 0.01	layer:2	batch: 128	hidden:64 heads=2
#P_100 lr: 0.01	layer:2	batch: 32	hidden:32 heads=2
#P_150 lr: 0.01	layer:2	batch: 32	hidden:32 heads=2

for p in P:
    for t in T:
        if mode=='test':
            model='csdlstm_2_mask_ma_2'#,'bi_lstm_ma''lstm_cnn''transformer''cnn_lstm_ma'
            device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")#容器
            if model=='csdlstm_2_mask_ma_2':
                if p==50:
                    GRU_model=csdlstm_network_2_mask_ma.smile_lc(hidden_size=64,output_size=3, n_layers=2,n_heads=2).to(device)
                if p==100:
                    GRU_model=csdlstm_network_2_mask_ma.smile_lc(hidden_size=32,output_size=3, n_layers=2,n_heads=2).to(device)
                if p==150:
                    GRU_model=csdlstm_network_2_mask_ma.smile_lc(hidden_size=32,output_size=3, n_layers=2,n_heads=2).to(device)
            model_path = 'D:\Project\Intenrion_feature_map\Dataset\Data_417\Models\github\Model/model_perception_'+str(p)+'.pkl'

            evaluation.load_model(model_path,GRU_model)
            testx = np.load('D:\Project\Intenrion_feature_map\Dataset\Data_417\Models\github\Date_perception_'+str(p)+'/testx.npy')
            testy = np.load('D:\Project\Intenrion_feature_map\Dataset\Data_417\Models\github\Date_perception_'+str(p)+'/testy.npy')
            real=[];pre=[]
            
            for i in range(len(testx)):
                t_x = np.array(testx[i], dtype='float64')
                t_x = np.reshape(t_x, (1,10,55))
                testx_torch = torch.tensor(t_x).float().to(device)
                pred = GRU_model.predict(testx_torch)
                if testy[i][0]==1:#左转
                    real.append(1)
                if testy[i][1]==1:#右转
                    real.append(2)
                if testy[i][2] == 1:#车道保持
                    real.append(3)
                pred = pred.detach().cpu().numpy()[0]
                m_id=max_index(pred)
                if m_id==0:
                    pre.append(1)
                if m_id==1:
                    pre.append(2)
                if m_id==2:
                    pre.append(3)
        book = xlwt.Workbook()
        sheet = book.add_sheet('Sheet1')
        col=['real','pre']
        for i in range(len(col)):
            sheet.write(0,i,col[i])
        for i in range(len(pre)):
            sheet.write(i+1, 0, real[i])
            sheet.write(i + 1, 1, pre[i])
        save_path = 'D:\Project\Intenrion_feature_map\Dataset\Data_417\Models\github/P_'+str(p)+'_result.xls'
        book.save(save_path)