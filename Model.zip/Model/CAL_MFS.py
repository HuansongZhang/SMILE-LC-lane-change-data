import pandas as pd
from sklearn.metrics import classification_report

model=['csdlstm_2_mask_ma_2']#'mask_Transformer','mask_lstm_cnn','mask_cnn_lstm_ma','mask_bi_lstm_ma''csdlstm_2_mask_ma_2'
P=['50','100','150']
for m in model:
    for p in P:
        print(m,p)
        df = pd.read_excel('D:\Project\Intenrion_feature_map\Dataset\Data_417\Models\github\P_'+p+'_result.xls')#T_4_result_58_60_all_3LC
        # 列A是真实标签，列B是预测标签
        y_true = df['real']
        y_pred = df['pre']
        report=classification_report(y_true,y_pred,digits=4)
        print(report)