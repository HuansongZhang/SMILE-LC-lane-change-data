import os
import xlwt
import pandas as pd
import torch
# import data_pro
from sklearn.metrics import mean_squared_error,mean_absolute_percentage_error
import numpy as np
import time
from sklearn import metrics
from sklearn.metrics import accuracy_score,mean_squared_error,r2_score
import random
import shutil
#分别输出流量速度占有率的MAPE、RMSE
def evaluate(label,pred):
    # label = data_pro.scal_data_inverse(label)
    # pred = data_pro.scal_data_inverse(pred)#逆标准化
    f_MAPE=mean_absolute_percentage_error(label[:,0],pred[:,0])
    f_RMSE=np.sqrt(mean_squared_error(label[:,0],pred[:,0]))
    o_MAPE = mean_absolute_percentage_error(label[:,1], pred[:,1])
    o_RMSE = np.sqrt(mean_squared_error(label[:,1], pred[:,1]))
    s_MAPE = mean_absolute_percentage_error(label[:,2], pred[:,2])
    s_RMSE = np.sqrt(mean_squared_error(label[:,2], pred[:,2]))
    return f_MAPE,f_RMSE,o_MAPE,o_RMSE,s_MAPE,s_RMSE


def save_model(model,save_path):
    torch.save(model.state_dict(), save_path)

def load_model(save_path,model):
    model.load_state_dict(torch.load(save_path))

def trans_xls(index):
    re_index=[]
    for i in range(len(index)):
        if not np.isnan(index[i]):
            re_index.append(float(index[i]))
        else:
            break
    return re_index

def Accuracy(real,pre):
    Cor=0
    for i in range(len(real)):
        if real[i]==pre[i]:
            Cor+=1
    return Cor/len(real)

def Accuracy_all(real_1,pre_1,real_2,pre_2,real_3,pre_3):
    Cor=0
    for i in range(len(real_1)):
        if real_1[i]==pre_1[i] and real_2[i]==pre_2[i] and real_3[i]==pre_3[i]:
            Cor+=1
    return Cor/len(real_1)

def f1_score(y_true, y_pred):
    tp = np.sum(np.logical_and(y_true == 1, y_pred == 1))
    fp = np.sum(np.logical_and(y_true == 0, y_pred == 1))
    fn = np.sum(np.logical_and(y_true == 1, y_pred == 0))
    precision = tp / (tp + fp + 1e-16)
    recall = tp / (tp + fn + 1e-16)
    f1 = 2 * (precision * recall) / (precision + recall + 1e-16)
    return f1
